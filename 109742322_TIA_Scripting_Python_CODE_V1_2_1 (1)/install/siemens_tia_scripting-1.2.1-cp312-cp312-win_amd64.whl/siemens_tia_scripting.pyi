from typing import List
from typing import Optional
from typing import Tuple
from enum import Enum

# this file is auto - generated

def open_portal(portal_mode: Optional[Enums.PortalMode] = None, version: Optional[str] = None) -> Portal:
    """
Open a new TIA Portal instance
Version-string in format major.minor e.g. \"18.0\"

*Returns* &rarr; `Portal` TIA Portal instance

| Parameters | Type | Description |
| --- | --- | --- |
| portal_mode | Enums.PortalMode | With or without user-interface |
| version | str | Version string of TIA Portal to be used in format major.minor e.g. 18.0, (Latest installed TIA Portal version by default) |

Example usage

```python
portal = siemens_tia_scripting.open_portal(portal_mode = siemens_tia_scripting.Enums.PortalMode.WithGraphicalUserInterface, version = "18.0")
```
    """
    ...
def attach_portal(portal_mode: Optional[Enums.PortalMode] = None, version: Optional[str] = None) -> Portal:
    """
Attach to running TIA Portal instance
Version-string in format major.minor e.g. \"18.0\"

*Returns* &rarr; `Portal` TIA Portal instance

| Parameters | Type | Description |
| --- | --- | --- |
| portal_mode | Enums.PortalMode | With or without user-interface |
| version | str | Version string of TIA Portal to be used in format major.minor e.g. 18.0, (Latest installed TIA Portal version by default) |

```python
portal = siemens_tia_scripting.attach_portal(portal_mode = Enums.PortalMode.WithGraphicalUserInterface, version = "18.0")
```
    """
    ...
def open_attach_project(project_file_path: str, portal_mode: Optional[Enums.PortalMode] = None, server_project_view: Optional[bool] = None ) -> Project:
    """
Attach to running TIA Portal instance with already open project
Or opens the project with a new instance of fitting TIA Portal version

*Returns* &rarr; `Project` TIA Project instance

| Parameters | Type | Description |
| --- | --- | --- |
| project_file_path | str | Full path of the project file |
| portal_mode | Enums.PortalMode | With or without user-interface |
| server_project_view | str | Default: false. If parameter set to true, open in server project view |

```python
project = siemens_tia_scripting.open_attach_project(project_file_path = "C:\\ws\\testproj\\testproj.ap17", portal_mode = siemens_tia_scripting.Enums.PortalMode.WithGraphicalUserInterface)
```
    """
    ...
def get_installed_bundles() -> List[ProductBundle]:
    """
Get a list of installed TIA Portal bundles

*Returns* &rarr; `List[ProductBundle]` List of installed bundles

```python
product_bundles = siemens_tia_scripting.get_installed_bundles()
```
    """
    ...
def get_installed_products() -> List[Product]:
    """
Get a list of installed TIA Portal products

*Returns* &rarr; `List[Product]` List of installed products

```python
products = siemens_tia_scripting.get_installed_products()
```
    """
    ...
def set_umac_credentials(user_name: str, user_password: str, user_type: Enums.UmacUserMode):
    """
Set UMAC Credentials which will be used for protected libraries or projects

| Parameters | Type | Description |
| --- | --- | --- |
| user_name | str | User name |
| user_password | str | Password of the user |
| user_type | Enums.UmacUserMode | Project or global user |

```python
siemens_tia_scripting.set_umac_credentials(user_name = "admin", user_password = "Password123", user_type = Enums.UmacUserMode.Project)
```
    """
    ...
def encrypt_umac_config(umac_file_path: str, secret: str, secret_env_name: str) -> str:
    """
Encrypt UMAC and UMC configuration from the TIA Portal project with provided secret

| parameters | type | description |
| --- | --- | --- |
| umac_file_path | str | Full path of the umac config file |
| secret | str | Secret for the ecnryption |
| secret_env_name | str | Name of the environment variable where secret value is stored |

```python
siemens_tia_scripting.encrypt_umac_config(umac_file_path = "C:\\ws\\exportfolder\\exportUMAC.json", secret = "mySecret")
```
    """
    ...
def set_logging(path: str, console: bool):
    """
Set logging output path or console (stdout) output

| Parameters | Type | Description |
| --- | --- | --- |
| path | str | Fullpath of the log file |
| console | bool | Optional: True for Enable console output, False to disable the standard output to console window |

```python
siemens_tia_scripting.set_logging(path = "c:\\ws\\tiascripting.log", console = False)
```
    """
    ...
class Enums:
    class PortalMode:
        WithGraphicalUserInterface: int
        WithoutGraphicalUserInterface: int
        AnyUserInterface: int
    class UmacUserMode:
        Project: int
        Global: int
    class ExportFormats:
        SimaticML: int
        ExternalSource: int
        SimaticSD: int
    class ExportOptions:
        WithDefaults: int
        Nan: int
        WithReadOnly: int
    class CleanUpMode:
        PreserveDefaultVersionOfUnusedTypes: int
        DeleteUnusedTypes: int
    class LibraryExportOptions:
        Nan: int
        WithLibraryVersionInfoFile: int
        OnlyLibraryVersionInfoFile: int
    class HarmonizeOptions:
        HarmonizePathsAndNames: int
        HarmonizePaths: int
        HarmonizeNames: int
    class DependenciesMode:
        DoNotAutomaticallyCreateOrReleaseDependencies: int
        AutomaticallyCreateOrReleaseDependenciesIfRequired: int
class ApplicationTest:
    def get_name(self) -> str:
        """
Get the name of the Test Suite application test

*Returns* &rarr; `str` Name of the application test

```python
name = app_test.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the Test Suite application test

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property of the Application Test |

```python
property_value = app_test.get_property(name = "Property")
```
        """
        ...
    def export(self, target_directory_path: str):
        """
Export the Test Suite application test

The folder "Application tests" will be automatically created on the `target_directory_path`, if not already exists.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |

```python
app_test.export(target_directory_path = "C:\\ws\\export")
```
        """
        ...
    def set_scope(self, plc_name: str, instance_name: Optional[str] = None, execution_mode: Optional[int] = None):
        """
Set the scope of the Test Suite application test

| Parameters | Type | Description |
| --- | --- | --- |
| plc_name | str | Name of the PLC to be used |
| instance_name | str | PLCSIM Instance name (only V19 and higher) |
| execution_mode | integer (enum) | (only V19 and higher) [1: 'SystemManagedPLCSIMInstance', 2: 'ExternallyManagedPLCSIMInstance'] |

```python
app_test.set_scope(plc_name = "PLC_1")
```
        """
        ...


class ExternalSource:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def block_gen(self):
        """
Generate the blocks from the external source

```python
ext_source.block_gen()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class ForceTable:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def is_consistent(self) -> bool:
        """
Check if the force table is consistent

*Returns* &rarr; `bool` True if consistent

```python
value = force_table.is_consistent()
```
        """
        ...
    def show_in_editor(self):
        """
Open the object in the editor

```python
plc_object.show_in_editor()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_fingerprints(self) -> List[Tuple[str, str]]:
        """
Get all fingerprint data for the object

*Returns* -> `List[Tuple[str, str]]` fingerprints

```python
fingerprints = plcdata.get_fingerprints()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...


class GlobalLibrary:
    def get_name(self) -> str:
        """
Get the name of the global library

*Returns* &rarr; `str` Name of the global library

```python
name = global_lib.get_name()
```
        """
        ...
    def save(self):
        """
Save the global library

```python
global_lib.save()
```
        """
        ...
    def get_author(self) -> str:
        """
Get author of the global library

*Returns* &rarr; `str` Name of the author

```python
author = global_lib.get_author()
```
        """
        ...
    def get_path(self) -> str:
        """
Get the path of the global library

*Returns* &rarr; `str` Full path of the library

```python
path = global_lib.get_path()
```
        """
        ...
    def is_modified(self) -> bool:
        """
Check if the global library was modified

*Returns* &rarr; `bool` State if library was modified

```python
state = global_lib.is_modified()
```
        """
        ...
    def is_read_only(self) -> bool:
        """
Check if the global library is readonly

*Returns* &rarr; `bool` State if global library is readonly

```python
state = global_lib.is_read_only()
```
        """
        ...
    def update_library(self, update_mode: int, delete_mode: int, conflict_mode: int, type_guids: Optional[List[str]] = None, library_name: Optional[str] = None ):
        """
Update target library with type(s) from source, if no target library selected the project library will be updated

| Parameters | Type | Description |
| --- | --- | --- |
| update_mode | integer (enum) | [1: 'ForceSetAnyUpdatedVersionAsDefault', 2: 'NoDefaultVersionChange', 3: 'SetOnlyHigherUpdatedVersionAsDefault'] |
| delete_mode | integer (enum) | [0: 'AutomaticallyDelete', 1: 'DoNotDelete'] |
| conflict_mode | integer (enum) | [1: 'CancelIfStructureConflicts', 2: 'RetainStructure', 3: 'UpdateStructure'] |
| type_guids | List[str] | Optional: This option should be used to select specific source type or types. If empty, all types in project library are selected |
| library_name | str | Optional: This option should be used when a specific global library has to be updated. If no name provided, the project library of the current project will be selected |

```python
global_lib.update_library(update_mode = 1, delete_mode = 1, conflict_mode = 3, type_guids = ["93826aed-7eac-4380-b4f4-f58e2707c862", "1fb57e17-f627-45f7-b7b8-644954b8888b"], library_name = "MyGlobalLibrary")
```
        """
        ...
    def update_project(self, update_mode: int, delete_mode: int, conflict_mode: int, type_guids: Optional[List[str]] = None):
        """
Update current project with type(s) from global library

| Parameters | Type | Description |
| --- | --- | --- |
| update_mode | integer (enum) | [1: 'ForceSetAnyUpdatedVersionAsDefault', 2: 'NoDefaultVersionChange', 3: 'SetOnlyHigherUpdatedVersionAsDefault'] |
| delete_mode | integer (enum) | [0: 'AutomaticallyDelete', 1: 'DoNotDelete'] |
| conflict_mode | integer (enum) | [1: 'CancelIfStructureConflicts', 2: 'RetainStructure', 3: 'UpdateStructure'] |
| type_guids | List[str] | Optional: This option should be used to select specific source type or types. If empty, all types in project library are selected  |

```python
global_lib.update_project(update_mode = 1, delete_mode = 1, conflict_mode = 3, type_guids = ["93826aed-7eac-4380-b4f4-f58e2707c862", "1fb57e17-f627-45f7-b7b8-644954b8888b"])
```
        """
        ...
    def harmonize_project(self, harmonize_options: int, type_guids: Optional[List[str]] = None ):
        """
Harmonize type instances in project using global library. If type_guids provided, only the seletected types will be used for update

| Parameters | Type | Description |
| --- | --- | --- |
| harmonize_options | integer (enum) | [0: 'HarmonizePathsAndNames', 1: 'HarmonizePaths', 2: 'HarmonizeNames'] |
| type_guids | List[str] | Optional: This option should be used to select specific source type or types. If empty, all types in project library are selected |
```python
global_lib.harmonize_project(harmonize_options: 0, type_guids: ["779c66b7-8fe2-46c0-a8a9-7da387b2521b","bb856213-036d-47e4-9e8b-129e3c1606f6"])
```
        """
        ...
    def archive(self, target_directory_path: str, archive_name: str, delete_existing_archive: bool):
        """
Archive the TIA Portal library

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path where archive should be placed |
| archive_name | str | Name of the archive file |
| delete_existing_archive | bool | Set if the output file should be deleted first |

```python
global_lib.archive(target_directory_path = "C:\\ws\\newfolder", archive_name = "testglobalib" , delete_existing_archive = True)
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def clean_up(self, folder_path: Optional[str] = None ):
        """
Performs the cleanup of the GlobalLibrary, without deleteing the complete types

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path  | str | Optional: The target base path within the project library where the imported folder hierarchy will be recreated |

```python
global_lib.clean_up()
```
        """
        ...
    def get_types(self) -> List[LibraryType]:
        """
Get the library types of the folder

*Returns* &rarr; `List[LibraryType]` List of types

```python
types = global_lib.get_types()
```
        """
        ...
    def find_library_type(self, library_type_name: str) -> LibraryType:
        """
Find the library type by name

*Returns* &rarr; `LibraryType` Library type

| Parameters | Type | Description |
| --- | --- | --- |
| library_type_name | str | Name of the library type |

```python
type = global_lib.find_library_type(library_type_name = "MyType")
```
        """
        ...
    def close_global_library(self):
        """
Close the global library instance

```python
global_lib.close_global_library()
```
        """
        ...
    def create_folder(self, folder_path: str ):
        """
Create new folder at specified path in the library

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path  | str | Optional: The target base path within the global library where the imported folder hierarchy will be recreated |

```python
global_lib.create_folder(folder_path = "myFolder/subFolderExample")
```
        """
        ...
    def delete_folder(self, folder_path: str):
        """
Delete specified folder in global library

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path  | str | Optional: The target base path within the global library where the imported folder hierarchy will be recreated |

```python
global_lib.delete_folder(folder_path = "myFolder/subFolderExample")
```
        """
        ...

class GlobalLibraryInfo:
    def get_name(self) -> str:
        """
Get the name of the global library info

*Returns* &rarr; `str` Name of the global library info

```python
name = global_lib_info.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...

class Hmi:
    def get_name(self) -> str:
        """
Get the name of the HMI

*Returns* &rarr; `str` Name of the HMI

```python
hmi_name = hmi.get_name()
```
        """
        ...
    def get_hmi_type(self) -> str:
        """
Get the type of the HMI

*Returns* &rarr; `str` Type of the HMI

```python
hmi_type = hmi.get_hmi_type()
```
        """
        ...
    def open_device_editor(self):
        """
Open the editor of the HMI-device in TIA Portal

```python
hmi.open_device_editor()
```
        """
        ...
    def compile_hardware(self) -> bool:
        """
Compile the hardware of the HMI

*Returns* &rarr; `bool` Result of the compile

Returns true if compile has errors, otherwise returns false

```python
result = hmi.compile_hardware()
```
        """
        ...
    def compile_software(self) -> bool:
        """
Compile the software of the HMI

*Returns* &rarr; `bool` Result of the compile

Returns true if compile has errors, otherwise returns false

```python
result = hmi.compile_software()
```
        """
        ...
    def upgrade_hardware(self, full_upgrade: bool):
        """
Update hardware of the HMI

If `full_upgrade` is set to True, all devices will be changed to the newest available order number (Device type) and firmware:

from CPU1511F 6ES7 511-1FK0**0**-0AB0 **V1.7** to 6ES7 511-1FK0**0**-0AB0 **V1.8**.

With full upgrade: from CPU1511F 6ES7 511-1FK0**0**-0AB0 **V1.7** to 6ES7 511-1FL0**3**-0AB0 **V3.0**.

| Parameters | Type | Description |
| --- | --- | --- |
| full_upgrade | bool | Set if for full upgrade (latest order number and firmware version) |

```python
hmi.upgrade_hardware(full_upgrade = True)
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...
    def get_hmi_tag_tables(self, folder_path: Optional[str] = None) -> List[HmiTagTable]:
        """
Get the list of the HMI Tag Tables

*Returns* &rarr; `List[HmiTagTable]` List of the HMI Tag tables

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
hmi_tag_tables = hmi.get_hmi_tag_tables(folder_path = "group1/group2")
```
        """
        ...
    def get_screens(self, folder_path: Optional[str] = None) -> List[HmiScreen]:
        """
Get the list of the HMI Screens

*Returns* &rarr; `List[HmiScreen]` List of the HMI Screens

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
hmi_screens = hmi.get_screens(folder_path = "group1/group2")
```
        """
        ...
    def get_text_lists(self) -> List[HmiTextList]:
        """
Get the list of the HMI Text Lists

*Returns* &rarr; `List[HmiTextList]` List of the HMI Text lists

```python
hmi_lists = hmi.get_text_lists()
```
        """
        ...
    def get_scripts(self, folder_path: Optional[str] = None) -> List[HmiScript]:
        """
Get the list of the HMI Scripts (VB Comfort), (JavaScript Unified)

*Returns* &rarr; `List[HmiScript]` List of the HMI Script

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
hmi_scripts = hmi.get_scripts(folder_path = "group1/group2")
```
        """
        ...
    def get_alarms(self) -> List[HmiAlarm]:
        """
Get the list of the HMI Alarms

*Returns* &rarr; `List[HmiAlarm]` List of the HMI Alarms

```python
hmi_alarms = hmi.get_alarms()
```
        """
        ...
    def get_alarm_classes(self) -> List[HmiAlarmClass]:
        """
Get the list of the HMI Alarm Classes

*Returns* &rarr; `List[HmiAlarmClass]` List of the HMI Alarm Classes

```python
hmi_alarms = hmi.get_alarms_classes()
```
        """
        ...
    def get_connections(self) -> List[HmiConnection]:
        """
Get the list of the HMI Connection

*Returns* &rarr; `List[HmiAlarm]` List of the HMI Connection

```python
connections = hmi.get_connections()
```
        """
        ...
    def get_cycles(self) -> List[HmiCycle]:
        """
Get the list of the HMI Cycles

*Returns* &rarr; `List[HmiCycle]` List of the HMI Cycles

```python
cycles = hmi.get_cycles()
```
        """
        ...
    def get_graphic_lists(self) -> List[HmiGraphicList]:
        """
Get the list of the HMI GraphicLists

*Returns* &rarr; `List[HmiGraphicList]` List of the HMI GraphicLists

```python
graph_lists = hmi.get_graphic_lists()
```
        """
        ...
    def get_global_screen_elements(self) -> HmiScreen:
        """
Get the Hmi screen global elements

*Returns* &rarr; `HmiScreen` Hmi screen global elements

```python
global_elements = hmi.get_global_screen_elements()
```
        """
        ...
    def get_screen_overview(self) -> HmiScreen:
        """
Get the Hmi screen overview

*Returns* &rarr; `HmiScreen` Hmi screen overview

```python
screen_overview = hmi.get_screen_overview()
```
        """
        ...
    def get_slide_in_screens(self, folder_path: Optional[str] = None) -> List[HmiScreen]:
        """
Get the list of the HMI SlideIn Screens

*Returns* &rarr; `List[HmiScreen]` List of the HMI Screens

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
hmi_slide_in_screens = hmi.get_slide_in_screens(folder_path = "group1/group2")
```
        """
        ...
    def import_hmi_tags(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import tags from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the HMI's group structure where the imported folder hierarchy will be recreated |

```python
hmi.import_hmi_tags(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\Tags")
```
        """
        ...
    def import_connections(self, import_root_directory: str):
        """
Import connections from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
hmi.import_hmi_tags(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\Connections")
```
        """
        ...
    def import_cycles(self, import_root_directory: str):
        """
Import cycles from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
hmi.import_cycles(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\Cycles")
```
        """
        ...
    def import_scripts(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import scripts from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the HMI's group structure where the imported folder hierarchy will be recreated |

```python
hmi.import_scripts(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\Scripts")
```
        """
        ...
    def import_text_lists(self, import_root_directory: str):
        """
Import Text lists from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
hmi.import_text_lists(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\Text lists")
```
        """
        ...
    def import_graphic_lists(self, import_root_directory: str):
        """
Import graphic lists from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
hmi.import_graphic_lists(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\Graphics")
```
        """
        ...
    def import_screens(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import screens from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the HMI's group structure where the imported folder hierarchy will be recreated |

```python
hmi.import_screens(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\Screens")
```
        """
        ...
    def import_popup_screens(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import popup screens from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the HMI's group structure where the imported folder hierarchy will be recreated |

```python
hmi.import_popup_screens(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\PopUpScreens")
```
        """
        ...
    def import_template_screens(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import template screens from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the HMI's group structure where the imported folder hierarchy will be recreated |

```python
hmi.import_template_screens(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\TemplateScreens")
```
        """
        ...
    def import_slidein_screens(self, import_root_directory: str):
        """
Import slide in screens from a directory to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
hmi.import_slidein_screens(import_root_directory = "C:\\ws\\importfolder\\HMI_1\\SlideinScreens")
```
        """
        ...
    def import_global_elements(self, import_file: str):
        """
Import global elements screen to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_file | str | Global elements import file |

```python
hmi.import_global_elements(import_file = "C:\\ws\\importfolder\\HMI_1\\GlobalElements.xml")
```
        """
        ...
    def import_screen_overview(self, import_file: str):
        """
Import screen overview to the HMI

| Parameters | Type | Description |
| --- | --- | --- |
| import_file | str | Screen overview import file |

```python
hmi.import_screen_overview(import_file = "C:\\ws\\importfolder\\HMI_1\\ScreenOverview.xml")
```
        """
        ...

class HmiAlarm:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiAlarmClass:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiConnection:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiCycle:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiGraphicList:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiScreen:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiScript:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiTag:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiTagTable:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class HmiTextList:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class LibraryType:
    def get_name(self) -> str:
        """
Get the name of the library type

*Returns* &rarr; `str` Name of the type

```python
name = lib_type.get_name()
```
        """
        ...
    def get_author(self) -> str:
        """
Get the author of the library type

*Returns* &rarr; `str` Author of the type

```python
author = lib_type.get_author()
```
        """
        ...
    def get_guid(self) -> str:
        """
Get the guid of the library type

*Returns* &rarr; `str` Guid of the type

```python
guid = lib_type.get_guid()
```
        """
        ...
    def get_versions(self) -> List[LibraryTypeVersion]:
        """
Get the versions of the library type

*Returns* &rarr; `List[LibraryTypeVersion]` Versions of the type

```python
versions = lib_type.get_versions()
```
        """
        ...
    def find_version(self, version: str) -> LibraryTypeVersion:
        """
Find the version of the library type

*Returns* &rarr; `LibraryTypeVersion` Version des Bibliothekstyp

```python
typeversion = lib_type.find_version(version = "1.0.0")
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = lib_type.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = lib_type.get_path_full()
```
        """
        ...
    def get_comment(self) -> str:
        """
Get text value from the comment. Language is selected by the current editing language.

*Returns* &rarr; `str` Comment text

```python
comment = lib_type.get_comment()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class LibraryTypeVersion:
    def get_author(self) -> str:
        """
Get the author of the library type version

*Returns* &rarr; `str` Author

```python
author = projectlib.get_author()
```
        """
        ...
    def get_guid(self) -> str:
        """
Get the GUID of the library type version

*Returns* &rarr; `str` GUID

```python
guid = lib_type_version.get_guid()
```
        """
        ...
    def get_version_number(self) -> str:
        """
Get the version number of the library type version

*Returns* &rarr; `str` version number

```python
version_number = lib_type_version.get_version_number()
```
        """
        ...
    def get_modified_date(self) -> str:
        """
Get the modification date of the library type version

*Returns* &rarr; `str` Modification date

```python
date = lib_type_version.get_modified_date()
```
        """
        ...
    def get_state(self) -> str:
        """
Get the state of the library type version

*Returns* &rarr; `str` State of the library type version

```python
state = lib_type_version.get_state()
```
        """
        ...
    def get_type_object(self) -> LibraryType:
        """
Get the type of the library type version

*Returns* &rarr; `LibraryType` Library type object

```python
lib_type = lib_type_version.get_type_object()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def find_instances(self, device_name: Optional[str] = None) -> List[object]:
        """
Get the list of instances of library type version

*Returns* &rarr; `List[object]` List of the object instances

| Parameters | Type | Description |
| --- | --- | --- |
| device_name | str | Optional: Name of the device where to search instance(e.g., PLC or HMI) |

```python
blocks = lib_type_version.find_instances()
```
        """
        ...
    def instantiate(self, device_name: str, software_unit_name: Optional[str] = None, folder_path: Optional[str] = None):
        """
Create an Instance in the PLC or HMI of the current type version

| Parameters | Type | Description |
| --- | --- | --- |
| device_name | str | Name of the PLC Software or HMI Software e.g. HMI_RT_1 |
| software_unit_name | str | Optional: Name of the PLC Software Unit |
| folder_path | str | Optional: group or folders structure e.g. group1/group2 |

```python
lib_type_version.instantiate(device_name = "PLC_1", software_unit_name: "Unit1", folder_path: "group1/group2")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = lib_type_version.get_supported_export_format()
```
        """
        ...
    def export(self, target_directory_path: str, export_format: str, library_export_options: Enums.LibraryExportOptions, keep_folder_structure: Optional[bool] = None ):
        """
Export library type

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_format | str |  Optional: Export format, by default SimaticSD, use get_supported_export_format() to get differnt formats |
| library_export_options | Enums.LibraryExportOptions | Optional: Export options of the Library by default WithLibraryVersionInfoFile |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
lib_type_version.export(library_export_options = ts.Enums.LibraryExportOptions.WithLibraryVersionInfoFile, export_format = "SimaticML", keep_folder_structure = true)
```
        """
        ...
    def edit(self, device_name: Optional[str] = None) -> LibraryTypeVersion:
        """
Edit the library type version for a specific device.

*Returns* &rarr; `LibraryTypeVersion` The edited library type version object.

| Parameters | Type | Description |
| --- | --- | --- |
| device_name | str | Optional: Name of the device where to search instance(e.g., PLC or HMI) |


```python
edited_version = lib_type_version.edit(device_name="PLC_1")
```
        """
        ...
    def release(self, dependencies_mode: Enums.DependenciesMode, version: str, author: str, comment: str) -> None:
        """
Release the library type version.

| Parameters | Type | Description |
| --- | --- | --- |
| dependencies_mode | Enums.DependenciesMode | Mode for dependencies |
| version | str | Version string |
| author | str | Author name |
| comment | str | Release comment |

```python
lib_type_version.release(dependencies_mode=ts.Enums.DependenciesMode.AutomaticallyCreateOrReleaseDependenciesIfRequired, version="1.0.0", author="John", comment="Initial release")
```
        """
        ...
    def discard(self):
        """
Discard changes to the library type version.

```python
lib_type_version.discard()
```
        """
        ...
    def set_as_default(self):
        """
Set this library type version as the default.

```python
lib_type_version.set_as_default()
```
        """
        ...
    def get_comment(self) -> str:
        """
Get the comment for this library type version.

*Returns* &rarr; `str` The comment.

```python
comment = lib_type_version.get_comment()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class NamedValueType:
    def get_name(self) -> str:
        """
Get the name of the Named value data type

*Returns* &rarr; `str` Name of the NVT

```python
name = nvt.get_name()
```
        """
        ...
    def get_namespace(self) -> str:
        """
Get the name of the Named value data type namespace

*Returns* &rarr; `str` Name of the namespace

```python
name = nvt.get_namespace()
```
        """
        ...
    def export(self, target_directory_path: str, keep_folder_structure: Optional[bool] = None):
        """
Export the Named value data type

If `keep_folder_structure` is set to true, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
nvt.export(target_directory_path = "C:\\ws\\export")
```
        """
        ...

class Plc:
    def get_name(self) -> str:
        """
Get the name of the PLC

*Returns* &rarr; `str` Name of the PLC

```python
plc_name = plc.get_name()
```
        """
        ...
    def open_device_editor(self):
        """
Open the editor of the PLC-device in TIA Portal

```python
plc.open_device_editor()
```
        """
        ...
    def get_online_state(self) -> str:
        """
Get the current online state of the PLC

*Returns* &rarr; `str` Online state

```python
plc.get_online_state()
```
        """
        ...
    def go_offline(self):
        """
Go offline with the PLC

```python
plc.go_offline()
```
        """
        ...
    def go_online(self, pc_interface_type: str, pc_interface_name: str, target_interface: str) -> str:
        """
Go online with the PLC

*Returns* &rarr; `str` Online status

| Parameters | Type | Description |
| --- | --- | --- |
| pc_interface_type | str | Configuration mode |
| pc_interface_name | str | PC Interface name |
| target_interface | str | API_V21: IP address or target interface, under v21 only target interface |

```python
plc.go_online(pc_interface_type = "PN/IE", pc_interface_name = "PLCSIM", target_interface = "1 X1")
```
        """
        ...
    def download(self, pc_interface_type: str, pc_interface_name: str, target_interface: str) -> str:
        """
Download the PLC

*Returns* &rarr; `str` Result of the download

| Parameters | Type | Description |
| --- | --- | --- |
| pc_interface_type | str | Configuration mode |
| pc_interface_name | str | PC Interface name |
| target_interface | str | IP address |

```python
result = plc.download(pc_interface_type = "PN/IE", pc_interface_name = "PLCSIM", target_interface = "1 X1")
```
        """
        ...
    def download_to_memory_card(self, download_directory: str, is_plcsim_advanced: Optional[bool] = None) -> str:
        """
Download the PLC-configuration to memory card

*Returns* &rarr; `str` Result of the download

| Parameters | Type | Description |
| --- | --- | --- |
| download_directory | str | Download directory |
| is_plcsim_advanced | bool | True: Plc sim advanced download is configured, by default false for the CPU download |

```python
result = plc.download_to_memory_card(download_directory = "E:\\", is_plcsim_advanced = True)
```
        """
        ...
    def get_plc_tag_tables(self, folder_path: Optional[str] = None) -> List[PlcTagTable]:
        """
Get the list of the PLC Tag Tables

*Returns* &rarr; `List[PlcTagTable]` List of the PLC Tag tables

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
plc_tag_tables = plc.get_plc_tag_tables(folder_path = "group1/group2")
```
        """
        ...
    def update_module_description(self) -> bool:
        """
Update the module description of the PLC

*Returns* &rarr; `bool` Result state

```python
result = plc.update_module_description()
```
        """
        ...
    def compile_hardware(self) -> bool:
        """
Compile the hardware of the PLC

*Returns* &rarr; `bool` Result of the compile

Returns true if compile has errors, otherwise returns false

```python
result = plc.compile_hardware()
```
        """
        ...
    def compile_software(self) -> bool:
        """
Compile the software of the PLC

*Returns* &rarr; `bool` Result of the compile

Returns true if compile has errors, otherwise returns false

```python
result = plc.compile_software()
```
        """
        ...
    def upgrade_hardware(self, full_upgrade: bool):
        """
Upgrade the hardware the PLC

If `full_upgrade` is set to True, all devices will be changed to the newest available order number (Device type) and firmware:

from CPU1511F 6ES7 511-1FK0**0**-0AB0 **V1.7** to 6ES7 511-1FK0**0**-0AB0 **V1.8**.

With full upgrade: from CPU1511F 6ES7 511-1FK0**0**-0AB0 **V1.7** to 6ES7 511-1FL0**3**-0AB0 **V3.0**.

| Parameters | Type | Description |
| --- | --- | --- |
| full_upgrade | bool | Set if for full upgrade (latest order number and firmware version) |

```python
plc.upgrade_hardware(full_upgrade = True)
```
        """
        ...
    def compare_to_online(self) -> bool:
        """
Compare actual PLC state to the online state

*Returns* &rarr; `bool` Result of the compare

Returns false if folders are Identical, otherwise returns true

```python
result = plc.compare_to_online()
```
        """
        ...
    def get_program_blocks(self, folder_path: Optional[str] = None) -> List[ProgramBlock]:
        """
Get the list of program blocks

*Returns* &rarr; `List[ProgramBlock]` List of the program blocks

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
blocks = plc.get_program_blocks(folder_path = "group1/group2")
```
        """
        ...
    def get_system_blocks(self) -> List[SystemBlock]:
        """
Get the list of system blocks

*Returns* &rarr; `List[SystemBlock]` List of the system blocks

```python
blocks = plc.get_system_blocks()
```
        """
        ...
    def get_user_data_types(self, folder_path: Optional[str] = None) -> List[UserDataType]:
        """
Get the list of PLC data types

*Returns* &rarr; `List[UserDataType]` List of the PLC data types

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
udts = plc.get_user_data_types(folder_path = "group1/group2")
```
        """
        ...
    def get_external_sources(self, folder_path: Optional[str] = None) -> List[ExternalSource]:
        """
Get the list of external source files

*Returns* &rarr; `List[ExternalSource]` List of the external source files of the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
ext_sources = plc.get_external_sources()
```
        """
        ...
    def get_force_tables(self) -> List[ForceTable]:
        """
Get the list of force tables

*Returns* &rarr; `List[ForceTable]` List of the force tables of the PLC

```python
tables = plc.get_force_tables()
```
        """
        ...
    def get_watch_tables(self, folder_path: Optional[str] = None) -> List[WatchTable]:
        """
Get the list of watch tables

*Returns* &rarr; `List[WatchTable]` List of the watch tables of the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
tables = plc.get_watch_tables()
```
        """
        ...
    def get_technology_objects(self, folder_path: Optional[str] = None) -> List[TechnologyObject]:
        """
Get the list of technology objects

*Returns* &rarr; `List[TechnologyObject]` List of the technology objects of the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path | str | The group path of the item |

```python
tos = plc.get_technology_objects()
```
        """
        ...
    def get_software_units(self) -> List[SoftwareUnit]:
        """
Get the list of software units

*Returns* &rarr; `List[SoftwareUnit]` List of the software units

```python
software_units = plc.get_software_units()
```
        """
        ...
    def get_safety_administration(self) -> SafetyAdministration:
        """
Get Safety administration of the PLC

*Returns* &rarr; `SafetyAdministration` Safety Administration of the PLC

```python
sa = plc.get_safety_administration()
```
        """
        ...
    def import_blocks(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import program blocks from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the PLC's group structure where the imported folder hierarchy will be recreated |

```python
plc.import_blocks(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\Program blocks")
```
        """
        ...
    def import_plc_tags(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import tags from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the PLC's group structure where the imported folder hierarchy will be recreated |

```python
plc.import_plc_tags(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\PLC tags")
```
        """
        ...
    def import_data_types(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import user data types from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the PLC's group structure where the imported folder hierarchy will be recreated |

```python
plc.import_data_types(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\PLC data types")
```
        """
        ...
    def import_technology_objects(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import technology objects from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the PLC's group structure where the imported folder hierarchy will be recreated |

```python
plc.import_technology_objects(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\Technology objects")
```
        """
        ...
    def import_watch_tables(self, import_root_directory: str, target_folder_path: Optional[str] = None):
        """
Import watch tables from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |
| target_folder_path | str | Optional: The target base path within the PLC's group structure where the imported folder hierarchy will be recreated |

```python
plc.import_watch_tables(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\Watch and force tables")
```
        """
        ...
    def create_software_unit(self, name: str):
        """
Create software unit on the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Software unit new name |

```python
plc.create_software_unit(name = "Unit 1")
```
        """
        ...
    def safety_print(self, print_file: str) -> bool:
        """
Create a safety printout of the PLC and print it to a file

If the file already exists, it is overwritten.

*Returns* &rarr; `bool` Returns true on success

| Parameters | Type | Description |
| --- | --- | --- |
| print_file | str | Full path of the printout file |

```python
plc.safety_print(print_file = "C:\\ws\\safetyprint\\F_PLC_Printout.pdf")
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...


class PlcTag:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class PlcTagTable:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def get_plc_tags(self) -> List[PlcTag]:
        """
Get the list of PLC tags

*Returns* &rarr; `List[PlcTag]` List of the PLC tags

```python
plctags = table.get_plc_tags()
```
        """
        ...
    def get_user_constants(self) -> List[UserConstant]:
        """
Get the list of the user constants

*Returns* &rarr; `List[UserConstant]` List of the PLC constants

```python
constants = table.get_user_constants()
```
        """
        ...
    def export_cross_references(self, target_directory_path: str, filter: int):
        """
Export cross references of the PLC tag table
filter &rarr; integer - [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects']

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| filter | integer (enum) | [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects'] |

```python
table.export_cross_references(target_directory_path = "C:\\ws\\exportcrossreferences", filter = 2)
```
        """
        ...
    def show_in_editor(self):
        """
Open the object in the editor

```python
plc_object.show_in_editor()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_fingerprints(self) -> List[Tuple[str, str]]:
        """
Get all fingerprint data for the object

*Returns* -> `List[Tuple[str, str]]` fingerprints

```python
fingerprints = plcdata.get_fingerprints()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class Portal:
    def get_process_id(self) -> int:
        """
Get the TIA Portal process ID

*Returns* &rarr; `int` TIA Portal process id

```python
id = portal.get_process_id()
```
        """
        ...
    def open_project(self, project_file_path: str, server_project_view: Optional[bool] = None ) -> Project:
        """
Open a TIA Portal project or local session - optional in server view

*Returns* &rarr; `Project` TIA Portal project

| Parameters | Type | Description |
| --- | --- | --- |
| project_file_path | str | Full path of the project file |
| server_project_view | str | Default: false. If parameter set to true, open in server project view |

```python
project = portal.open_project(project_file_path = "C:\\ws\\testproj\\testproj.ap17")
```
        """
        ...
    def open_project_with_copy(self, project_file_path: str, target_directory_path: str, delete_existing_project: bool) -> Project:
        """
Open a TIA Portal project or local session in separate folder

*Returns* &rarr; `Project` TIA Portal project

| Parameters | Type | Description |
| --- | --- | --- |
| project_file_path | str | Full path of the project file |
| target_directory_path | str | Temporary path where the project should be copied before opened |
| delete_existing_project | bool | Defines if the temporary project should be deleted |

```python
project = portal.open_project_with_copy(project_file_path = "C:\\ws\\testproj\\testproj.ap17", target_directory_path = "C:\\ws\\temp" , delete_existing_project = True)
```
        """
        ...
    def retrieve_archive(self, target_directory_path: str, archive_file_path: str, delete_existing_project: bool) -> Project:
        """
Retrieve a TIA Portal project archive

*Returns* &rarr; `Project` TIA Portal project

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Temporary path where project should be copied before opened |
| archive_file_path | str | Full path of the archived project file |
| delete_existing_project | bool | Defines if the temporary project should be deleted |

```python
project = portal.retrieve_archive(archive_file_path = "C:\\ws\\testproj\\testproj.zap17", target_directory_path = "C:\\ws\\temp" , delete_existing_project = True)
```
        """
        ...
    def create_project(self, target_directory_path: str, project_name: str, delete_existing_project: bool) -> Project:
        """
Create a new TIA Portal project

*Returns* &rarr; `Project` TIA Portal project

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Temporary path where project should be copied before opened |
| project_name | str | Name of the new project |
| delete_existing_project | bool | Defines if the temporary project should be deleted |

```python
project = portal.create_project(target_directory_path = "C:\\ws\\temp" , project_name = "MyNewProject" delete_existing_project = True)
```
        """
        ...
    def get_project(self) -> Project:
        """
Get opened TIA Portal project of the current TIA Portal instance

*Returns* &rarr; `Project` TIA Portal project

```python
project = portal.get_project()
```
        """
        ...
    def get_global_library_infos(self) -> List[GlobalLibraryInfo]:
        """
Get a list of global library infos of the current TIA Portal instance

*Returns* &rarr; `List[GlobalLibraryInfo]` List of the global library information

```python
global_lib_infos = portal.get_global_library_infos()
for info in global_lib_infos:
...
```
        """
        ...
    def get_global_library(self, library_name: str) -> GlobalLibrary:
        """
Get global library by name

*Returns* &rarr; `GlobalLibrary` Global Library

| Parameters | Type | Description |
| --- | --- | --- |
| library_name | str | Name of the global library |

```python
global_lib = portal.get_global_library(library_name = "GlobalLib1")
```
        """
        ...
    def open_global_library(self, library_path: str) -> GlobalLibrary:
        """
Open global library by path

*Returns* &rarr; `GlobalLibrary` Global Library

| Parameters | Type | Description |
| --- | --- | --- |
| library_path | str | Full path of the global library |

```python
global_lib = portal.open_global_library(library_path = "C:\\ws\\testlib\\testlib.al17")
```
        """
        ...
    def open_global_library_with_copy(self, target_directory_path: str, library_path: str, delete_existing_project: bool) -> GlobalLibrary:
        """
Open global library from a copy

*Returns* &rarr; `GlobalLibrary` Global Library

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Temporary path where the library should be copied before opened |
| library_path | str | Full path of the global library |
| delete_existing_project | bool | Defines if the temporary project should be deleted |

```python
global_lib = portal.open_global_library_with_copy(target_directory_path = "C:\\ws\\temp", library_path = "C:\\ws\\testlib\\testlib.al17", delete_existing_project = True)
```
        """
        ...
    def create_global_library(self, target_directory_path: str, library_name: str, delete_existing_project: bool) -> GlobalLibrary:
        """
Create a new TIA Portal project

*Returns* &rarr; `GlobalLibrary` Global Library

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Temporary path where the library should be copied before opened |
| library_name | str | Name of the new global library |
| delete_existing_project | bool | Defines if the temporary library should be deleted |

```python
global_lib = portal.create_global_library(target_directory_path = "C:\\ws\\temp" , library_name = "MyLib1" delete_existing_project = True)
```
        """
        ...
    def retrieve_archive_library(self, target_directory_path: str, archive_file_path: str, delete_existing_project: bool) -> GlobalLibrary:
        """
Retrieve a TIA Portal library archive

*Returns* &rarr; `GlobalLibrary` Global Library

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Temporary path where library should be copied before opened |
| archive_file_path | str | Full path of the archived library file |
| delete_existing_project | bool | Defines if the temporary project should be deleted |

```python
global_lib = portal.retrieve_archive_library(target_directory_path = "C:\\ws\\temp", archive_file_path = "C:\\ws\\testproj\\testlib.zal17", delete_existing_project = True)
```
        """
        ...
    def close_portal(self):
        """
Attempts to close the TIA Portal instance (requires all projects to be saved or changes explicitly discarded)

```python
portal.close_portal()
```
        """
        ...
    def show_online_finger_prints(self, mode: str, pc_interface: str, ip_address: str):
        """
Show fingerprints of the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| mode | str | Configuration mode |
| pci_interface | str | PC Interface name |
| ip_address | str | IP adress |

```python
portal.show_online_finger_prints(mode = "PN/IE", pci_interface = "PLCSIM", ip_address = "192.168.0.10")
```
        """
        ...
    def get_project_servers(self, server: Optional[str] = None ) -> List[ProjectServer]:
        """
Get a list of TIA Project-Servers found by host-filter

*Returns* &rarr; `List[ProjectServer]` List of TIA Project-Servers

| Parameters | Type | Description |
| --- | --- | --- |
| server | str | Server Name or URL |

```python
portal.get_project_servers(server = "CompanyServer")
```
        """
        ...
    def detach(self):
        """
Detach from the TIA Portal instance

```python
portal.detach()
```
        """
        ...
    def add_project_server(self, url: str, name: str) -> ProjectServer :
        """
Add new TIA Project-Server

*Returns* &rarr; `ProjectServer` TIA Project-Server

| Parameters | Type | Description |
| --- | --- | --- |
| url | str | URL of the TIA Project-Server |
| name | str | Name of new server |

```python
portal.add_project_server(url = "https://project.server.net:8735/", name = "MyNewServer")
```
        """
        ...

class Product:
    def get_name(self) -> str:
        """
Get the name of the TIA Portal product

*Returns* &rarr; `str` Name of the TIA Portal product

```python
product_name = product.get_name()
```
        """
        ...
    def get_release(self) -> str:
        """
Get the release of the TIA Portal product

*Returns* &rarr; `str` Release tag of the TIA Portal product

```python
product_release = product.get_release()
```
        """
        ...
    def get_version(self) -> str:
        """
Get the version of the TIA Portal product

*Returns* &rarr; `str` Version of the TIA Portal product

```python
product_version = product.get_version()
```
        """
        ...

class ProductBundle:
    def get_title(self) -> str:
        """
Get the title of the TIA Portal Bundle

*Returns* &rarr; `str` Title of the Siemens bundle

```python
bundle_title = bundle.get_title()
```
        """
        ...
    def get_release(self) -> str:
        """
Get the release of the TIA Portal Bundle

*Returns* &rarr; `str` Release of the Siemens bundle

```python
bundle_release = bundle.get_release()
```
        """
        ...
    def get_products(self) -> List[Product]:
        """
Get the list of products of the TIA Portal Bundle

*Returns* &rarr; `List[Product]` List of Siemens products

```python
bundle_products = bundle.get_products()
```
        """
        ...

class ProgramBlock:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def compile(self):
        """
Compile the program block

```python
programblock.compile()
```
        """
        ...
    def is_consistent(self) -> bool:
        """
Check if the program block is consistent

*Returns* &rarr; `bool` True if consistent

```python
value = programblock.is_consistent()
```
        """
        ...
    def export_cross_references(self, target_directory_path: str, filter: int):
        """
Export cross references of the program block
filter &rarr; integer - [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects']

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| filter | integer (enum) | [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects'] |

```python
programblock.export_cross_references(target_directory_path = "C:\\ws\\exportcrossreferences", filter = 2)
```
        """
        ...
    def show_in_editor(self):
        """
Open the object in the editor

```python
plc_object.show_in_editor()
```
        """
        ...
    def get_type_version_guid(self) -> str:
        """
Get the GUID of the type version

*Returns* &rarr; `str` GUID

```python
guid = plc_object.get_type_version_guid()
```
        """
        ...
    def get_type_guid(self) -> str:
        """
Get the GUID of the type

*Returns* &rarr; `str` GUID

```python
guid = plc_object.get_type_guid()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_fingerprints(self) -> List[Tuple[str, str]]:
        """
Get all fingerprint data for the object

*Returns* -> `List[Tuple[str, str]]` fingerprints

```python
fingerprints = plcdata.get_fingerprints()
```
        """
        ...
    def is_library_type(self) -> bool:
        """
Check if the object is a library type

*Returns* &rarr; `bool` True if is a library type

```python
value = plcdata.is_library_type()
```
        """
        ...
    def set_know_how_protection(self, password: str):
        """
Set know-how protection on the program block with the given password.

| Parameters | Type | Description |
| --- | --- | --- |
| password | str | Password for KnowHow Protection |

```python
programblock.set_know_how_protection(password = "Password!123")
```
        """
        ...
    def remove_know_how_protection(self, password: str):
        """
Remove know-how protection from the program block with the given password.

| Parameters | Type | Description |
| --- | --- | --- |
| password | str | Password for KnowHow Protection |

```python
programblock.remove_know_how_protection(password = "Password!123")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class Project:
    def get_portal(self) -> Portal:
        """
Get the TIA Portal instance from the current project

```python
portal = project.get_portal()
```
        """
        ...
    def save(self):
        """
Save the TIA Portal project

```python
project.save()
```
        """
        ...
    def close(self):
        """
Closes the TIA Portal project without saving any pending changes

WARNING: All unsaved modifications will be permanently lost
```python
project.close()
```
        """
        ...
    def set_simulation_support(self, value: bool):
        """
Set the simulation support for the TIA Portal project

| Parameters | Type | Description |
| --- | --- | --- |
| value | bool | Set the value of the simulation support |

```python
project.set_simulation_support(value = True)
```
        """
        ...
    def archive(self, target_directory_path: str, archive_name: str, delete_existing_archive: bool) -> str:
        """
Archive the TIA Portal project

*Returns* &rarr; `str` Full path of the new archive

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path where archive should be placed |
| archive_name | str | name of the archive file |
| delete_existing_archive | bool | Set if the output file should be deleted first |

```python
archive_fullpath = project.archive(target_directory_path = "C:\\ws\\newfolder", archive_name = "testproj" , delete_existing_archive = True)
```
        """
        ...
    def save_as(self, target_directory_path: str, project_name: str) -> str:
        """
Save the TIA Portal project under another path and name

*Returns* &rarr; `str` Full path of the saved project

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path where project should be saved |
| project_name | str | Name of the project name |

```python
project_file_path = project.save_as(target_directory_path = "C:\\ws\\newfolder", project_name = "testproj")
```
        """
        ...
    def export_cax_data(self, export_file_path: str, log_file_path: str) -> bool:
        """
Export the CAx data of the TIA Portal project

*Returns* &rarr; `bool` Result state of the export

| Parameters | Type | Description |
| --- | --- | --- |
| export_file_path | str | Full path of the export file |
| log_file_path | str | Full path of the log file |

```python
result = project.export_cax_data(export_file_path = "C:\\ws\\exportfolder\\exportCAX.aml", log_file_path = "C:\\ws\\exportfolder\\exportCAX.log")
```
        """
        ...
    def import_cax_data(self, import_file_path: str, log_file_path: str) -> bool:
        """
Import CAx data to the TIA Portal project

*Returns* &rarr; `bool` Result state of the import

| Parameters | Type | Description |
| --- | --- | --- |
| import_file_path | str | Fullpath of the import file |
| log_file_path | str | Fullpath of the log file |

```python
result = project.import_cax_data(import_file_path = "C:\\ws\\importfolder\\importCAX.aml", log_file_path = "C:\\ws\\importfolder\\importCAX.log")
```
        """
        ...
    def open_topology_editor(self):
        """
Open the topology editor in TIA Portal for the TIA Portal project

```python
project.open_topology_editor()
```
        """
        ...
    def open_network_editor(self):
        """
Open the network editor in TIA Portal for the TIA Portal project

```python
project.open_network_editor()
```
        """
        ...
    def get_plcs(self) -> List[Plc]:
        """
Get a list of PLCs in the TIA Portal project

*Returns* &rarr; `List[Plc]` All PLC's as list

```python
plcs = project.get_plcs()
for plc in plcs:
...
```
        """
        ...
    def get_hmis(self) -> List[Hmi]:
        """
Get a list of HMIs in the TIA Portal project

*Returns* &rarr; `List[Hmi]` All HMI's as list

```python
hmis = project.get_hmis()
for hmi in hmis:
...
```
        """
        ...
    def get_application_tests(self) -> List[ApplicationTest]:
        """
Get a list of Test Suite application tests in the TIA Portal project

Needs Test Suite installed and licensed.

*Returns* &rarr; `List[ApplicationTest]` All Application tests as list

```python
tests = project.get_application_tests()
```
        """
        ...
    def get_system_tests(self) -> List[SystemTest]:
        """
Get a list of Test Suite system tests in the TIA Portal project

Needs Test Suite installed and licensed.

*Returns* &rarr; `List[SystemTest]` All System tests as list

```python
tests = project.get_system_tests()
```
        """
        ...
    def get_rule_sets(self) -> List[RuleSet]:
        """
Get a list of Test Suite Styleguide rule sets in the TIA Portal project

Needs Test Suite installed and licensed.

*Returns* &rarr; `List[RuleSet]` All Rule sets as list

```python
rule_sets = project.get_rule_sets()
```
        """
        ...
    def get_project_library(self) -> ProjectLibrary:
        """
Get the project library

*Returns* &rarr; `ProjectLibrary` Project library

```python
project_lib = project.get_project_library()
```
        """
        ...
    def web_block_generate(self):
        """
Generate Web block DBs according the user define pages

Web server must activated.

```python
project.web_block_generate()
```
        """
        ...
    def upgrade_hardware(self, full_upgrade: bool):
        """
Upgrade the devices to the latest order number and firmware version

If `full_upgrade` is set to True, all devices will be changed to the newest available order number (Device type) and firmware:

from CPU1511F 6ES7 511-1FK0**0**-0AB0 **V1.7** to 6ES7 511-1FK0**0**-0AB0 **V1.8**.

With full upgrade: from CPU1511F 6ES7 511-1FK0**0**-0AB0 **V1.7** to 6ES7 511-1FL0**3**-0AB0 **V3.0**.

| Parameters | Type | Description |
| --- | --- | --- |
| full_upgrade | bool | Set if for full upgrade (latest order number and firmware version) |

```python
project.upgrade_hardware(full_upgrade = True)
```
        """
        ...
    def sivarc_generate(self):
        """
Start SiVArc-generation

SiVArc must be installed and licensed.

```python
project.sivarc_generate()
```
        """
        ...
    def update_module_description(self):
        """
Update the module description of all devices in the project

```python
project.update_module_description()
```
        """
        ...
    def set_virtual_plc_support(self, value: bool):
        """
Set virtual PLC support in the project

Available only in V19 or higher

| Parameters | Type | Description |
| --- | --- | --- |
| value | bool | Set the value of the virtual support |

```python
project.set_virtual_plc_support(value = "True")
```
        """
        ...
    def import_umac_config(self, import_file_path: str) -> int:
        """
Import UMAC and UMC Configuration to the TIA Portal project

*Returns* &rarr; `int` Result state ReturnCode of the import

| Parameters | Type | Description |
| --- | --- | --- |
| import_file_path | str | Full path of the import file |
| secret | str | Secret for the encryption (optional if passwords encrypted) |
| secret_env_name | str | Name of the environment variable where Secret is stored (optional if passwords encrypted) |

```python
project.import_umac_config(import_file_path = "C:\\ws\\importfolder\\importUMAC.json", secret_env_name = "MYSECRETENV")
```
        """
        ...
    def export_umac_config(self, export_file_path: str):
        """
Export UMAC and UMC configuration from the TIA Portal project

If export file already exists, it will be overwritten

| Parameters | Type | Description |
| --- | --- | --- |
| export_file_path | str | Full path of the export file |

```python
project.export_umac_config(export_file_path = "C:\\ws\\exportfolder\\exportUMAC.json")
```
        """
        ...
    def import_password_policy(self, import_file_path: str):
        """
Import Password Policies to the TIA Portal project

| Parameters | Type | Description |
| --- | --- | --- |
| import_file_path | str | Full path of the import file |

```python
project.import_password_policy(import_file_path = "C:\\ws\\importfolder\\PWPolicy.json")
```
        """
        ...
    def export_password_policy(self, export_file_path: str):
        """
Export Password Policies from the TIA Portal project

If export file already exists, it will be overwritten

| Parameters | Type | Description |
| --- | --- | --- |
| export_file_path | str | Full path of the import file |

```python
project.export_password_policy(export_file_path = "C:\\ws\\exportfolder\\exportPWPolicy.json")
```
        """
        ...
    def delete(self):
        """
Delete the TIA Portal project

```python
project.delete()
```
        """
        ...
    def start_transaction(self, undo_text: str, dialog_text: str):
        """
Start exclusive access and new transaction

| Parameters | Type | Description |
| --- | --- | --- |
| undo_text | str | Text on the Undo button |
| dialog_text | str | Text on the dialog during the transaction |

```python
project.start_transaction(undo_text = "MyUndoDescription", dialog_text = "MyExclusiveAccess")
```
        """
        ...
    def end_transaction(self, rollback: Optional[bool] = None):
        """
End transaction and exclusive access

| Parameters | Type | Description |
| --- | --- | --- |
| rollback | bool | Set if changes during transaction should be rolled back (default: false) |

```python
project.end_transaction()
```
        """
        ...
    def update_transaction(self, dialog_text: str):
        """
Update transaction of the running exclusive access

| Parameters | Type | Description |
| --- | --- | --- |
| dialog_text | str | Text on the dialog during the transaction |

```python
project.update_transaction(dialog_text = "MyNewExclusiveAccess")
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def is_session(self) -> bool:
        """
Checks if current project is a local session

*Returns* &rarr; bool True if local session

```python
is_session = project.is_session()
```
        """
        ...
    def commit_and_close(self, commit_message: str):
        """
Commit message and close the project

*Returns* &rarr; `int` Revision number of the commit

| Parameters | Type | Description |
| --- | --- | --- |
| commit_message | str | Commit message |

```python
rev_number = project.commit_and_close(commit_message = "MyCommitMessage")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class ProjectLibrary:
    def get_types(self) -> List[LibraryType]:
        """
Get the library types of the folder

*Returns* &rarr; `List[LibraryType]` List of types

```python
types = projectlib.get_types()
```
        """
        ...
    def find_library_type(self, library_type_name: str) -> LibraryType:
        """
Find the library type by name

*Returns* &rarr; `LibraryType` Library type

| Parameters | Type | Description |
| --- | --- | --- |
| library_type_name | str | Name of the library type |

```python
type = projectlib.find_library_type(library_type_name = "MyType")
```
        """
        ...
    def clean_up(self, clean_up_mode: Enums.CleanUpMode, folder_path: Optional[str] = None ):
        """
Cleans up the library to delete unused versions of types based on the cleaUpMode specified

| Parameters | Type | Description |
| --- | --- | --- |
| clean_up_mode | Enums.CleanUpMode | Clean up mode |
| folder_path  | str | Optional: The target base path within the project library where the imported folder hierarchy will be recreated |

```python
projectlib.clean_up(clean_up_mode = siemens_tia_scripting.Enums.CleanUpMode.DeleteUnusedTypes)
```
        """
        ...
    def import_library_types(self, import_root_directory: str, device_name: Optional[str] = None, software_unit_name: Optional[str] = None, plc_folder_path: Optional[str] = None, library_folder_path: Optional[str] = None ):
        """
Import library types a directory to the Project Library

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str |  The source directory path from which all files and folders will be imported |
| device_name | str | Optional: Name of the PLC Software |
| software_unit_name | str | Optional: Name of the PLC Software Unit fromt he PLC |
| plc_folder_path | str | Optional: The target base path within the PLC's group structure where the imported folder hierarchy will be recreated |
| library_folder_path  | str | Optional: The target base path within the project library where the imported folder hierarchy will be recreated |

```python
projectlib.import_library_types(import_root_directory= "C:\\ws\\importLibraryTypes", device_name: "PLC_1",  software_unit_name: "Unit1", plc_folder_path: "group1/group2", library_folder_path: "ImportLibFolder/Types")
```
        """
        ...
    def update_library(self, library_name: str, update_mode: int, delete_mode: int, conflict_mode: int, type_guids: Optional[List[str]] = None ):
        """
Update target library with type(s) from source

| Parameters | Type | Description |
| --- | --- | --- |
| library_name | str | The name of the target Global library to update |
| update_mode | integer (enum) | [1: 'ForceSetAnyUpdatedVersionAsDefault', 2: 'NoDefaultVersionChange', 3: 'SetOnlyHigherUpdatedVersionAsDefault'] |
| delete_mode | integer (enum) | [0: 'AutomaticallyDelete', 1: 'DoNotDelete'] |
| conflict_mode | integer (enum) | [1: 'CancelIfStructureConflicts', 2: 'RetainStructure', 3: 'UpdateStructure'] |
| type_guids | List[str] | Optional: This option should be used to select specific source type or types. If empty, all types in project library are selected |

```python
project_lib.update_library(library_name = "MyGlobalLibrary", update_mode = 1, delete_mode = 1, conflict_mode = 3, type_guids = ["93826aed-7eac-4380-b4f4-f58e2707c862", "1fb57e17-f627-45f7-b7b8-644954b8888b"])
```
        """
        ...
    def update_project(self, delete_mode: int, type_guids: Optional[List[str]] = None ):
        """
Update type instances in project using project library. If type_guids provided, only the seletected types will be used for update

| Parameters | Type | Description |
| --- | --- | --- |
| delete_mode | integer (enum) | [0: 'AutomaticallyDelete', 1: 'DoNotDelete'] |
| type_guids | List[str] | Optional: This option should be used to select specific source type or types. If empty, all types in project library are selected |

```python
project_lib.update_library(delete_mode: 1, type_guids: ["779c66b7-8fe2-46c0-a8a9-7da387b2521b","bb856213-036d-47e4-9e8b-129e3c1606f6"])
```
        """
        ...
    def harmonize_project(self, harmonize_options: int, type_guids: Optional[List[str]] = None ):
        """
Harmonize type instances in project using project library. If type_guids provided, only the seletected types will be used for update

| Parameters | Type | Description |
| --- | --- | --- |
| harmonize_options | integer (enum) | [0: 'HarmonizePathsAndNames', 1: 'HarmonizePaths', 2: 'HarmonizeNames'] |
| type_guids | List[str] | Optional: This option should be used to select specific source type or types. If empty, all types in project library are selected |

```python
project_lib.harmonize_project(harmonize_options: 0, type_guids: ["779c66b7-8fe2-46c0-a8a9-7da387b2521b","bb856213-036d-47e4-9e8b-129e3c1606f6"])
```
        """
        ...
    def create_folder(self, folder_path: str ):
        """
Create new folder at specified path in the library

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path  | str | Optional: The target base path within the project library where the imported folder hierarchy will be recreated |

```python
projectlib.create_folder(folder_path = "myFolder/subFolderExample")
```
        """
        ...
    def delete_folder(self, folder_path: str):
        """
Delete specified folder in project library

| Parameters | Type | Description |
| --- | --- | --- |
| folder_path  | str | Optional: The target base path within the project library where the imported folder hierarchy will be recreated |

```python
projectlib.delete_folder(folder_path = "myFolder/subFolderExample")
```
        """
        ...

class ProjectServer:
    def get_host(self) -> str:
        """
Get the host of the TIA Project-Server

*Returns* &rarr; `str` Host

```python
host = server_project.get_host()
```
        """
        ...
    def get_port(self) -> int:
        """
Get the port of the TIA Project-Server

*Returns* &rarr; `int` Port number

```python
port = server_project.get_port()
```
        """
        ...
    def get_server_name(self) -> str:
        """
Get the server name of the TIA Project-Server

*Returns* &rarr; `str` Server name

```python
name = server_project.get_server_name()
```
        """
        ...
    def print_info(self):
        """
Show information of the TIA Project-Server

```python
server_project.print_info()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def add_project(self, project_path: str) -> str:
        """
Add project to the project server

| Parameters | Type | Description |
| --- | --- | --- |
| project_path | str | Path of the projectfile |

```python
project_server.add_project(project_path = "D:\tia_sessions\MyTestSession\MyTestSession.als")
```
        """
        ...
    def create_local_session(self, server_project_path: str, session_directory_path: str, session_name: str, exclusive: Optional[bool] = None ) -> str:
        """
Create a local session and return the project-path

Warning: only ungrouped server projects are supported and can be retrieved. Group servers are supported from API V20.

*Returns* &rarr; `str` TIA Portal project local session fullpath

| Parameters | Type | Description |
| --- | --- | --- |
| server_project_path | str | Path of the project on Project-Server |
| session_directory_path | str | Local path of the session directory |
| session_name | str | Name of the session |
| exclusive | bool | Default: true Opens exclusive session |

```python
local_session_project_path = project_server.create_local_session(server_project_path = "myServerGroup/MyServerProject", session_directory_path = "C:\\ws\\sessionDir",session_name ="myLocalSession", exclusive = False )
```
        """
        ...
    def get_server_project_paths(self, group: Optional[str] = None) -> List[str]:
        """
Get all the project names from the selected TIA Project-Server

*Returns* &rarr; `List[str]` Paths of the projects

| Parameters | Type | Description |
| --- | --- | --- |
| group | str | Optional: group name |

```python
project_names = project_server.get_server_project_paths(group = "MyGroup")
```
        """
        ...
    def delete_local_session(self, session_file_path: str, server_project_path: str):
        """
Delete the local session

| Parameters | Type | Description |
| --- | --- | --- |
| session_file_path | str | Local session file path, supports .amc and also .als filepath |
| server_project_path | str | Path of the project on server |

```python
project_server.delete_local_session(session_file_path =  "C:\\ws\\tia-sessions\\myproject\\myproject.amc" ,  server_project_path =  "myGroup/serverproject")
```
        """
        ...

class RuleSet:
    def get_name(self) -> str:
        """
Get the name of the Test Suite style guide rule set

*Returns* &rarr; `str` Name of the rule set

```python
name = rule.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the Test Suite style guide rule set

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property of the rule set |

```python
property_value = rule.get_property(name = "Property")
```
        """
        ...
    def export(self, target_directory_path: str):
        """
Export the Test Suite style guide rule set

The folder "Style guide" will be automatically created on the `target_directory_path`, if not already exists.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |

```python
rule.export(target_directory_path = "C:\\ws\\export")
```
        """
        ...

class SafetyAdministration:
    def is_logged_on(self) -> bool:
        """
Check if user is logged in to Safety administration offline program

*Returns* &rarr; `bool` Status of login

```python
status = safety_admin.is_logged_on()
```
        """
        ...
    def is_password_set(self) -> bool:
        """
Check if the safety administration has a password set for the safety offline program

*Returns* &rarr; `bool` Status if password is set

```python
status = safety_admin.is_password_set()
```
        """
        ...
    def get_offline_serial_number(self) -> str:
        """
Get the offline serial number

*Returns* &rarr; `str` Offline serial number

```python
value = safety_admin.get_offline_serial_number()
```
        """
        ...
    def export_config(self, target_directory_path: str):
        """
Export the safety administration configuration

The folder "SafetyAdministration" will be automaticcally created on the `target_directory_path`, if not already exists.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |

```python
safety_admin.export_config(target_directory_path = "C:\\ws\\export")
```
        """
        ...
    def import_config(self, import_root_directory: str):
        """
Import the safety administration configuration

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Folder path for the import |

```python
safety_admin.import_config(import_root_directory = "C:\\ws\\exported\\SafetyAdministration")
```
        """
        ...

class SoftwareUnit:
    def get_name(self) -> str:
        """
Get the name of the software unit

*Return* &rarr; `str` Name of the software unit
*
```python
name = software_unit.get_name()
```
        """
        ...
    def compile(self):
        """
Compile the software unit

```python
software_unit.compile()
```
        """
        ...
    def export_configuration(self, export_file_path: str):
        """
Export the software unit configuration

| Parameters | Type | Description |
| --- | --- | --- |
| export_file_path | str | Full path for the configuration |

```python
software_unit.export_configuration(export_file_path = "C:\\ws\\export\\config.xml")
```
        """
        ...
    def import_configuration(self, import_file_path: str):
        """
Import the software unit configuration

| Parameters | Type | Description |
| --- | --- | --- |
| import_file_path | str | Full path for the configuration |

```python
software_unit.import_configuration(import_file_path = "C:\\ws\\export\\config.xml")
```
        """
        ...
    def get_plc_tag_tables(self) -> List[PlcTagTable]:
        """
Get the list of the PLC tag tables

*Returns* &rarr; `List[PlcTagTable]` List of the PLC tag tables of the software unit

```python
pcl_tag_tables = software_unit.get_plc_tag_tables()
```
        """
        ...
    def get_program_blocks(self) -> List[ProgramBlock]:
        """
Get the list of the program blocks

*Returns* &rarr; `List[ProgramBlock]` List of the program blocks of the software unit

```python
blocks = software_unit.get_program_blocks()
```
        """
        ...
    def get_system_blocks(self) -> List[SystemBlock]:
        """
Get the list of the system blocks

*Returns* &rarr; `List[SystemBlock]` List of the system blocks of the software unit

```python
blocks = software_unit.get_system_blocks()
```
        """
        ...
    def get_user_data_types(self) -> List[UserDataType]:
        """
Get the list of the user data types

*Returns* &rarr; `List[UserDataType]` List of the user data types of the software unit

```python
udts = software_unit.get_user_data_types()
```
        """
        ...
    def get_external_sources(self) -> List[ExternalSource]:
        """
Get the list of the external sources

*Returns* &rarr; `List[ExternalSource]` List of the external sources of the software unit

```python
ext_sources = software_unit.get_external_sources()
```
        """
        ...
    def get_named_value_types(self) -> List[NamedValueType]:
        """
Get the list of the named value types

*Returns* &rarr; `List[NamedValueType]` List of the named value types of the software unit

```python
nvts = software_unit.get_named_value_types()
```
        """
        ...
    def import_blocks(self, import_root_directory: str):
        """
Import program blocks from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
software_unit.import_blocks(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\Program blocks")
```
        """
        ...
    def import_plc_tags(self, import_root_directory: str):
        """
Import tags from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
software_unit.import_plc_tags(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\PLC tags")
```
        """
        ...
    def import_data_types(self, import_root_directory: str):
        """
Import user data types from a directory to the PLC

| Parameters | Type | Description |
| --- | --- | --- |
| import_root_directory | str | Directory of the import folder |

```python
software_unit.import_data_types(import_root_directory = "C:\\ws\\importfolder\\PLC_1\\PLC data types")
```
        """
        ...
    def export_cross_references(self, target_directory_path: str, filter: int):
        """
Export cross references of the software unit object
filter &rarr; integer - [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects']

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| filter | integer (enum) | [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects'] |

```python
software_unit.export_cross_references(target_directory_path = "C:\\ws\\exportcrossreferences", filter = 2)
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class SystemBlock:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def compile(self):
        """
Compile the system block

```python
system_block.compile()
```
        """
        ...
    def is_consistent(self) -> bool:
        """
Check if the system block is consistent

*Returns* &rarr; `bool` True if consistent

```python
value = system_block.is_consistent()
```
        """
        ...
    def export_cross_references(self, target_directory_path: str, filter: int):
        """
Export cross references of the system block 
filter &rarr; integer - [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects']

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| filter | integer (enum) | [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects'] |

```python
system_block.export_cross_references(target_directory_path = "C:\\ws\\exportcrossreferences", filter = 2)
```
        """
        ...
    def show_in_editor(self):
        """
Open the object in the editor

```python
plc_object.show_in_editor()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_fingerprints(self) -> List[Tuple[str, str]]:
        """
Get all fingerprint data for the object

*Returns* -> `List[Tuple[str, str]]` fingerprints

```python
fingerprints = plcdata.get_fingerprints()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class SystemTest:
    def get_name(self) -> str:
        """
Get the name of the Test Suite system test

*Returns* &rarr; `str` Name of the system test

```python
name = sys_test.get_name()
```
        """
        ...
    def export(self, target_directory_path: str):
        """
Export the Test Suite system test

The folder "System tests" will be automatically created on the `target_directory_path`, if not already exists.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |

```python
sys_test.export(target_directory_path = "C:\\ws\\export")
```
        """
        ...
    def set_scope(self, opcua_server_address: str, opcua_server_interface_type: int, opcua_server_interface_folder_path: Optional[str] = None):
        """
Set the scope of the Test Suite system test

| Parameters | Type | Description |
| --- | --- | --- |
| opcua_server_address | str | OPC UA server adress e.g. opc.tcp://server.port/path |
| opcua_server_interface_type | integer (enum) | [1: 'UserDefined', 2: 'StandardSIMATIC'] |
| opcua_server_interface_folder_path | str | Folder path to interface files |

```python
sys_test.set_scope(opcua_server_address = "opc.tcp://server.port/path", opcua_server_interface_type = 1 )
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class TechnologyObject:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def compile(self):
        """
Compile the technology object

```python
to.compile()
```
        """
        ...
    def is_consistent(self) -> bool:
        """
Check if the technology object is consistent

*Returns* &rarr; `bool` True if consistent

```python
value = to.is_consistent()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_fingerprints(self) -> List[Tuple[str, str]]:
        """
Get all fingerprint data for the object

*Returns* -> `List[Tuple[str, str]]` fingerprints

```python
fingerprints = plcdata.get_fingerprints()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class UserConstant:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class UserDataType:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def compile(self):
        """
Compile the PLC data type

```python
udt.compile()
```
        """
        ...
    def is_consistent(self) -> bool:
        """
Check if the PLC data type is consistent

*Returns* &rarr; `bool` True if consistent

```python
value = udt.is_consistent()
```
        """
        ...
    def export_cross_references(self, target_directory_path: str, filter: int):
        """
Export the cross references of the PLC data type
filter &rarr; integer - [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects']

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| filter | integer (enum) | [1: 'AllObjects', 2: 'ObjectsWithReferences', 3: 'ObjectsWithoutReferences', 4: 'UnusedObjects'] |

```python
udt.export_cross_references(target_directory_path = "C:\\ws\\exportcrossreferences", filter = 2)
```
        """
        ...
    def get_type_version_guid(self) -> str:
        """
Get the GUID of the type version

*Returns* &rarr; `str` GUID

```python
guid = plc_object.get_type_version_guid()
```
        """
        ...
    def get_type_guid(self) -> str:
        """
Get the GUID of the type

*Returns* &rarr; `str` GUID

```python
guid = plc_object.get_type_guid()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_fingerprints(self) -> List[Tuple[str, str]]:
        """
Get all fingerprint data for the object

*Returns* -> `List[Tuple[str, str]]` fingerprints

```python
fingerprints = plcdata.get_fingerprints()
```
        """
        ...
    def is_library_type(self) -> bool:
        """
Check if the object is a library type

*Returns* &rarr; `bool` True if is a library type

```python
value = plcdata.is_library_type()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

class WatchTable:
    def get_name(self) -> str:
        """
Get the name of the object

*Returns* &rarr; `str` Name of the object

```python
name = tiap_object.get_name()
```
        """
        ...
    def get_property(self, name: str) -> str:
        """
Get the property of the object

Properties which are not string will be converted to string if possible.

*Returns* &rarr; `str` Value of the property as string

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Property name of the object |

```python
property_value = tiap_object.get_property(name = "CreationDate")
```
        """
        ...
    def export(self, target_directory_path: str, export_options: Optional[Enums.ExportOptions] = None, export_format: Optional[Enums.ExportFormats] = None, keep_folder_structure: Optional[bool] = None ):
        """
Export the object

If `keep_folder_structure` is set to True, all group names are represented hierarchically with folders.

| Parameters | Type | Description |
| --- | --- | --- |
| target_directory_path | str | Folder path for the export |
| export_options | Enums.ExportOptions | Optional: Export options, by default ExportOptions.None |
| export_format | Enums.ExportFormats | Optional: Export format, by default SimaticML |
| keep_folder_structure | bool | True: All group names are represented hierarchically with folders |

```python
tiap_object.export(target_directory_path = "C:\\ws\\export", export_options = Enums.ExportOptions.WithDefaults)
```
        """
        ...
    def is_consistent(self) -> bool:
        """
Check if the watch table is consistent

*Returns* &rarr; `bool` True if consistent

```python
value = watch_table.is_consistent()
```
        """
        ...
    def show_in_editor(self):
        """
Open the object in the editor

```python
plc_object.show_in_editor()
```
        """
        ...
    def delete(self):
        """
Delete the object

```python
tiap_object.delete()
```
        """
        ...
    def get_properties(self) -> List[str]:
        """
Get all properties of the object

*Returns* &rarr; `List[str]` Names of the attributes

```python
properties = tiap_object.get_properties()
```
        """
        ...
    def set_property(self, name:str, value: str) -> int:
        """
Set the property of the object

*Returns* &rarr; `int` Return code of the result

Sets a property of the object by assigning the given value, provided it is in the correct format.

- **Boolean**: "True" or "False"
- **Integer**: Whole numbers (e.g., "42")
- **Double**: Decimal numbers with a dot (e.g., "3.14")
- **Enum**: Either the option index (e.g., "0", "1", "2") or the corresponding string value (e.g., "OptionA", "OptionB").

| Parameters | Type | Description |
| --- | --- | --- |
| name | str | Name of the property from the object|
| value | str | String value for the property e.g. "1", "True", "MyNewString" |

```python
is_set = tiap_object.set_property(name = "Name", value = "MyNewName")
```
        """
        ...
    def get_supported_export_format(self):
        """
Returns list of supported export formats

*Returns* &rarr; `List[str]` supported format

```python
supported_formats = plc_object.get_supported_export_format()
```
        """
        ...
    def get_path_full(self) -> str:
        """
Get group path for an object until project

*Returns* &rarr; `str` group full path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_path(self) -> str:
        """
Get group path for an object until parent system folder

*Returns* &rarr; `str` group path

```python
group_path = plcdata.get_path_full()
```
        """
        ...
    def get_fingerprints(self) -> List[Tuple[str, str]]:
        """
Get all fingerprint data for the object

*Returns* -> `List[Tuple[str, str]]` fingerprints

```python
fingerprints = plcdata.get_fingerprints()
```
        """
        ...
    def get_identifier(self) -> str:
        """
Get the identifier of the object

*Returns* &rarr; `str` Identifier as string

```python
property_value = tiap_object.get_identifier()
```
        """
        ...

